const Notes = () => {
    const dispatch = useDispatch()
  
    const notes = useSelector(state => state.notes)
  
    return(
      <ul>
        {notes.map(note =>
          <Note
            key={note.id}
            note={note}
            handleClick={() => 
              dispatch(toggleImportanceOf(note.id))
            }
          />
        )}
      </ul>
    )
  }

  const notes = useSelector(state => state)

  const notes = useSelector(state => state.notes)

  import { filterChange } from '../reducers/filterReducer'
import { useDispatch } from 'react-redux'

const VisibilityFilter = (props) => {
  const dispatch = useDispatch()

  return (
    <div>
      all    
      <input 
        type="radio" 
        name="filter" 
        onChange={() => dispatch(filterChange('ALL'))}
      />
      important   
      <input
        type="radio"
        name="filter"
        onChange={() => dispatch(filterChange('IMPORTANT'))}
      />
      nonimportant 
      <input
        type="radio"
        name="filter"
        onChange={() => dispatch(filterChange('NONIMPORTANT'))}
      />
    </div>
  )
}

export default VisibilityFilter

import Notes from './components/Notes'
import NewNote from './components/NewNote'
import VisibilityFilter from './components/VisibilityFilter'

const App = () => {
  return (
    <div>
      <NewNote />
      <VisibilityFilter />
      <Notes />
    </div>
  )
}

export default App

const Notes = () => {
    const dispatch = useDispatch()
  
    const notes = useSelector(state => {
      if ( state.filter === 'ALL' ) {
        return state.notes
      }
      return state.filter  === 'IMPORTANT' 
        ? state.notes.filter(note => note.important)
        : state.notes.filter(note => !note.important)
    })
  
    return(
      <ul>
        {notes.map(note =>
          <Note
            key={note.id}
            note={note}
            handleClick={() => 
              dispatch(toggleImportanceOf(note.id))
            }
          />
        )}
      </ul>
    )

    useSelector(state => state.notes)

    const notes = useSelector(({ filter, notes }) => {
        if ( filter === 'ALL' ) {
          return notes
        }
        return filter  === 'IMPORTANT' 
          ? notes.filter(note => note.important)
          : notes.filter(note => !note.important)
      })

      const Filter = () => {
        const handleChange = (event) => {
          // input-field value is in variable event.target.value
        }
        const style = {
          marginBottom: 10
        }
      
        return (
          <div style={style}>
            filter <input onChange={handleChange} />
          </div>
        )
      }
      
      export default Filter