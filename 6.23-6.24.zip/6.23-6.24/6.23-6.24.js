import { createContext, useReducer, useContext } from 'react'

const CounterContext = createContext()

// ...

export const useCounterValue = () => {
  const counterAndDispatch = useContext(CounterContext)
  return counterAndDispatch[0]
}

export const useCounterDispatch = () => {
  const counterAndDispatch = useContext(CounterContext)
  return counterAndDispatch[1]
}

// ...

import { useCounterValue } from '../CounterContext'

const Display = () => {

  const counter = useCounterValue()
  return <div>
    {counter}
  </div>
}


export default Display

import { useCounterDispatch } from '../CounterContext'

const Button = ({ type, label }) => {

  const dispatch = useCounterDispatch()
  return (
    <button onClick={() => dispatch({ type })}>
      {label}
    </button>
  )
}

export default Button

